﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Xml;
using System.Xml.Linq;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;
using Microsoft.Win32;

namespace ParserIEBD 
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void CmbBox_Loaded(object sender, RoutedEventArgs e)
        {
            CmbBox.SelectedItem = CmbBox.Items.OfType<ComboBoxItem>().FirstOrDefault(item => item.Content.ToString() == "JSON");
        }
        private void UrlTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (UrlTextBox.Text == "Введите URL-адрес или вставьте текст")
            {
                UrlTextBox.Text = "";
                UrlTextBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void UrlTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UrlTextBox.Text))
            {
                UrlTextBox.Text = "Введите URL-адрес или вставьте текст";
                UrlTextBox.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UrlTextBox.Text;
            string data = "";

            LinksListBox.Items.Clear(); 

            // Проверка, является ли ввод URL-адресом
            if (Uri.IsWellFormedUriString(input, UriKind.Absolute))
            {
                try
                {
                    using (HttpClient client = new HttpClient())
                    {
                        data = await client.GetStringAsync(input);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке данных из URL: {ex.Message}");
                    return;
                }
            }
          
            else
            {
                // Проверка, существует ли файл по указанному пути
                if (File.Exists(input))
                {
                    try
                    {
                        data = File.ReadAllText(input);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при чтении файла: {ex.Message}");
                        return;
                    }
                }
                else
                {
                   
                    data = input;
                }
            }

            // Определение типа файла и преобразование в JSON
            string json = null;
            if (IsJson(data))
            {
                json = data; 
            }
            else if (IsXml(data))
            {
                json = ConvertXmlToJson(data);
            }
            else if (IsCsv(data))
            {
                json = ConvertCsvToJson(data);
            }
            else
            {
                json = ConvertTextToJson(data);
            }

            // Отображение JSON в ListBox
            if (json != null)
            {
                try
                {
                    // Форматируем JSON для удобочитаемости
                    JToken parsedJson = JToken.Parse(json);
                    string formattedJson = parsedJson.ToString(Newtonsoft.Json.Formatting.Indented);

                    // Разбиваем отформатированный JSON на строки и добавляем в ListBox
                    string[] lines = formattedJson.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                    foreach (string line in lines)
                    {
                        LinksListBox.Items.Add(line);
                    }
                }
                catch (JsonReaderException ex)
                {
                    MessageBox.Show($"Ошибка при разборе JSON: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Не удалось преобразовать данные в JSON.");
            }
        }

        // Вспомогательные методы для определения типа файла и преобразования в JSON

        private bool IsJson(string data)
        {
            try
            {
                JToken.Parse(data);
                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
        }

        private bool IsXml(string data)
        {
            try
            {
                XDocument.Parse(data);
                return true;
            }
            catch (XmlException)
            {
                return false;
            }
        }

        private bool IsCsv(string data)
        {
            // Простая проверка на CSV: наличие запятых или точек с запятой в первых строках
            string[] lines = data.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            if (lines.Length > 0)
            {
                return lines[0].Contains(",") || lines[0].Contains(";");
            }
            return false;
        }

        private string ConvertXmlToJson(string xmlData)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlData);

                // Remove the XML declaration
                if (doc.FirstChild is XmlDeclaration)
                    doc.RemoveChild(doc.FirstChild);

               
                XmlElement root = doc.CreateElement("root");
                while (doc.HasChildNodes)
                {
                    XmlNode firstChild = doc.FirstChild;
                    doc.RemoveChild(firstChild);
                    root.AppendChild(firstChild);
                }
                doc.AppendChild(root);


                return JsonConvert.SerializeXmlNode(doc, Newtonsoft.Json.Formatting.Indented, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при преобразовании XML в JSON: {ex.Message}");
                return null;
            }
        }

        private string ConvertCsvToJson(string csvData)
        {
            try
            {
                using (var reader = new StringReader(csvData))
                using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true, 
                    Delimiter = "," 
                }))
                {
                    var records = csv.GetRecords<dynamic>().ToList();
                    return JsonConvert.SerializeObject(records);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при преобразовании CSV в JSON: {ex.Message}");
                return null;
            }
        }

        private string ConvertTextToJson(string textData)
        {
            // Простейшее преобразование текста в JSON: каждая строка - отдельный элемент массива
            string[] lines = textData.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            return JsonConvert.SerializeObject(lines);
        }

        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|HTML файлы (*.html;*.htm)|*.html;*.htm|CSV файлы (*.csv)|*.csv|JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    string filePath = openFileDialog.FileName;
                    UrlTextBox.Text = filePath; 

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии файла: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string selectedFormat = (CmbBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            List<string> items = LinksListBox.Items.Cast<string>().ToList();

            if (items.Count == 0)
            {
                MessageBox.Show("Список пуст. Нечего сохранять.");
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = selectedFormat == "XML" ? "XML Files (*.xml)|*.xml" :
                                    selectedFormat == "JSON" ? "JSON Files (*.json)|*.json" :
                                    selectedFormat == "CSV" ? "CSV Files (*.csv)|*.csv" :
                                    "All Files (*.*)|*.*";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;

                switch (selectedFormat)
                {
                    case "XML":
                        SaveAsXml(filePath, items);
                        break;
                    case "JSON":
                        SaveAsJson(filePath, items);
                        break;
                    case "CSV":
                        SaveAsCsv(filePath, items);
                        break;
                    default:
                        MessageBox.Show("Выберите формат для сохранения.");
                        break;
                }
            }
        }

        private void SaveAsXml(string filePath, List<string> items)
        {
            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(List<string>));
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                serializer.Serialize(writer, items);
            }
        }

        private void SaveAsJson(string filePath, List<string> items)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(items, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        private void SaveAsCsv(string filePath, List<string> items)
        {
            File.WriteAllLines(filePath, items);
        }

    }
}
